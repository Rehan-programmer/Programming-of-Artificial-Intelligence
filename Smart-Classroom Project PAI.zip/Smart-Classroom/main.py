import cv2
import csv
from datetime import datetime

# Haarcascade face detector
detector = cv2.CascadeClassifier(
    cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
)

marked = []

def attendance(name):
    if name not in marked:
        with open("attendance.csv", "a", newline="") as f:
            writer = csv.writer(f)
            time = datetime.now().strftime("%H:%M:%S")
            writer.writerow([name, "Present", time])
            marked.append(name)


cap = cv2.VideoCapture(0)

ret, frame = cap.read()   # ✔ YES (required)

if not cap.isOpened():
    print("Camera not detected")
    exit()

while True:
    ret, frame = cap.read()

    if not ret:
        continue

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    faces = detector.detectMultiScale(gray, 1.3, 5)

    if len(faces) == 0:

        cv2.putText(
            frame,
            "Student Absent",
            (50, 50),
            cv2.FONT_HERSHEY_SIMPLEX,
            1,
            (0, 0, 255),
            2
        )

    else:

        for i, (x, y, w, h) in enumerate(faces):

            if i == 0:
                name = "Sarmad"
            elif i == 1:
                name = "RanaAneeb"
            else:
                name = "Unknown"

            attendance(name)

            cv2.rectangle(
                frame,
                (x, y),
                (x + w, y + h),
                (0, 255, 0),
                2
            )

            cv2.putText(
                frame,
                f"{name} Present",
                (x, y - 10),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.8,
                (0, 255, 0),
                2
            )

    cv2.imshow("Smart Classroom", frame)

    if cv2.waitKey(1) == 27:
        break

cap.release()
cv2.destroyAllWindows()